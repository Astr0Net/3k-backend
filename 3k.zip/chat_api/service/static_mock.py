import time
from chat_api.models import Message
from ..extensions import db
from ..utils.message_utils import sse
from ..utils.chat_utils import chat_brief

# ۱. اطلاعات استاتیک کمپانی‌ها و نظرات (مشابه خروجی job_scoring)
STATIC_JOBS_DATA = [
    {
        "title": "توسعه‌دهنده پایتون (Full Stack)",
        "company_name": "دیجی‌کالا",
        "location": "تهران",
        "paycheck": "۴۰-۶۰ میلیون",
        "requirements": ["Python", "Django", "React", "PostgreSQL"],
        "match_percent": 94.2,
        "job_url": "https://jobinja.ir/123",
        "source_site": "Jobinja",
        "company_reviews": {"score": 4.5, "count": 1200, "summary": "محیط پویا و مزایای رفاهی خوب"}
    },
    {
        "title": "برنامه‌نویس بک‌اند (Senior)",
        "company_name": "اسنپ",
        "location": "تهران (دورکاری)",
        "paycheck": "۵۰-۷۵ میلیون",
        "requirements": ["Python", "Go", "Microservices", "Redis"],
        "match_percent": 89.5,
        "job_url": "https://jobinja.ir/456",
        "source_site": "Jobinja",
        "company_reviews": {"score": 4.2, "count": 850, "summary": "تیم فنی بسیار قوی و چالش‌های جذاب"}
    },
    {
        "title": "AI Engineer",
        "company_name": "تپسی",
        "location": "تهران",
        "paycheck": "۴۵-۶۵ میلیون",
        "requirements": ["Python", "Machine Learning", "NLP", "Pandas"],
        "match_percent": 82.1,
        "job_url": "https://jobinja.ir/789",
        "source_site": "IranTalent",
        "company_reviews": {"score": 4.0, "count": 430, "summary": "فرآیندهای چابک و شفافیت سازمانی"}
    }
]

# ۲. متنی که مثلاً LLM بر اساس ۳ شغل بالا تولید کرده است
REPORT_PROMPT_RESULT = (
    "با بررسی رزومه شما و تحلیل فرصت‌های شغلی موجود در بازار، ۳ موقعیت برتر برای شما شناسایی شد.\n\n"
    "**تحلیل کلی:** شما در زمینه Python و فریمورک‌های وب تسلط بالایی دارید که تطابق ۹۴ درصدی با موقعیت دیجی‌کالا را نشان می‌دهد. "
    "همچنین دانش شما در حوزه داده، شما را به گزینه مناسبی برای تیم AI تپسی تبدیل می‌کند.\n\n"
    "**پیشنهاد:** تمرکز روی مهارت‌های Microservices می‌تواند شانس شما را برای رده‌های ارشد در اسنپ به شدت افزایش دهد."
)

def stream_static_reply(chat, user_msg, user_text: str, user_id: int, title_changed: bool):
    """
    شبیه‌سازی کامل فرآیند آنلاین:
    1. Meta (Analyze) -> 2. Job Scoring (Jobs) -> 3. LLM Report (Content) -> 4. Done
    """
    try:
        # گام ۱: ارسال META با نوع analyze
        # در این حالت فرانت متوجه می‌شود که باید منتظر کارت‌های شغلی باشد
        yield sse("meta", {
            "chat": chat_brief(chat),
            "user_message_id": user_msg.message_id,
            "type": "analyze", 
            "title_changed": title_changed,
        })

        # گام ۲: ارسال کارت‌های شغلی (Jobs)
        # این همان مرحله‌ای است که بعد از job_scoring صدا زده می‌شود
        time.sleep(1) # وقفه کوتاه برای طبیعی شدن حس پردازش
        yield sse("jobs", {
            "items": STATIC_JOBS_DATA
        })

        # گام ۳: استریم گزارش LLM (Content)
        # شبیه‌سازی تولید متن توسط مدل با استفاده از گزارش ساخته شده
        words = REPORT_PROMPT_RESULT.split(" ")
        full_text = ""

        for word in words:
            chunk = word + " "
            full_text += chunk
            yield sse("content", {"delta": chunk})
            time.sleep(0.04) # سرعت تایپ مدل

        # گام ۴: ذخیره پیام بات در دیتابیس
        bot_msg = Message(
            chat_id=chat.chat_id,
            content=full_text.strip(),
            role="assistant",
        )
        db.session.add(bot_msg)
        db.session.commit()

        # گام ۵: اعلام پایان (Done)
        yield sse("done", {
            "bot_message_id": bot_msg.message_id
        })

    except Exception as e:
        db.session.rollback()
        yield sse("error", {"message": f"خطای استاتیک: {str(e)}"})
