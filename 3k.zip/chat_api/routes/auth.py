"""
Auth Routes
=================

This module provides all authentication-related endpoints including:

- User registration
- User login (via username or email)
- JWT access token refresh
- JWT logout (token revocation)

The system supports:
- Normalized username input
- Email and phone number validation
- Duplicate checks before DB commit
- Secure password hashing using Werkzeug
- JWT-based authentication with token blocklisting
"""

from flask import Blueprint, request
from sqlalchemy.exc import IntegrityError
from sqlalchemy import or_

from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    jwt_required,
    get_jwt,
    get_jwt_identity,
)

from ..extensions import db
from chat_api.models import User, TokenBlocklist

from ..utils.response_utils import api_ok, api_error, normalize_username
from ..service.auth_validators import (
    validate_username,
    validate_password,
    validate_email,
    validate_phone_number,
)

auth_bp = Blueprint("auth", __name__)



# ============================================================
#                       REGISTER
# ============================================================

@auth_bp.route("/register", methods=["POST"])
def register():
    """
    Register a new user account.

    ---
    tags:
      - Auth
    summary: Create a new user account
    description: >
      Creates a new user with a username, email, phone number, and password.
      The username is normalized before validation and saving.
      Email and phone number are optional but must be unique if provided.

    consumes:
      - application/json

    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - username
            - password
          properties:
            username:
              type: string
              example: mohammad
            password:
              type: string
              example: StrongPass123
            email:
              type: string
              example: example@gmail.com
            phone_number:
              type: string
              example: +989123456789

    responses:
      201:
        description: User created successfully
      400:
        description: Validation error
      409:
        description: Duplicate username/email/phone
    """

    data = request.get_json(silent=True) or {}

    username = normalize_username(data.get("username"))
    password = data.get("password") or ""
    email = (data.get("email") or "").strip().lower()
    phone_number = (data.get("phone_number") or "").strip()

    # --------------------------------------------------------
    # Validate inputs
    # --------------------------------------------------------
    err = (
        validate_username(username)
        or validate_password(password)
        or validate_email(email)
        or validate_phone_number(phone_number)
    )
    if err:
        return api_error(err, 400)

    # --------------------------------------------------------
    # Check duplicates before commit
    # --------------------------------------------------------
    if User.query.filter_by(username=username).first():
        return api_error("username already exists", 409)

    if email and User.query.filter_by(email=email).first():
        return api_error("email already exists", 409)

    if phone_number and User.query.filter_by(phone_number=phone_number).first():
        return api_error("phone number already exists", 409)

    # --------------------------------------------------------
    # Create user object
    # --------------------------------------------------------
    user = User(
        username=username,
        email=email if email else None,
        phone_number=phone_number if phone_number else None,
    )
    user.set_password(password)

    db.session.add(user)

    # --------------------------------------------------------
    # Safe commit
    # --------------------------------------------------------
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return api_error("duplicate user data", 409)

    return api_ok(
        data={"user": user.to_dict()},
        message="user created",
        http_status=201,
    )



# ============================================================
#                       LOGIN
# ============================================================

@auth_bp.route("/login", methods=["POST"])
def login():
    """
    Authenticate a user and return JWT tokens.

    ---
    tags:
      - Auth
    summary: Login user
    description: >
      Logs in using either username or email along with a password.
      Returns access and refresh tokens upon successful authentication.

    consumes:
      - application/json

    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - username
            - password
          properties:
            username:
              type: string
              example: mohammad
            password:
              type: string
              example: StrongPass123

    responses:
      200:
        description: Login successful
      400:
        description: Missing username/email or password
      401:
        description: Invalid credentials
    """

    data = request.get_json(silent=True) or {}

    identifier = (data.get("username") or "").strip().lower()  # username or email
    password = data.get("password") or ""

    if not identifier or not password:
        return api_error("username/email and password are required", 400)

    # Login with username OR email
    user = User.query.filter(
        or_(
            User.username == identifier,
            User.email == identifier,
        )
    ).first()

    if not user or not user.check_password(password):
        return api_error("Invalid credentials", 401)

    access_token = create_access_token(identity=str(user.user_id))
    refresh_token = create_refresh_token(identity=str(user.user_id))

    return api_ok(
        data={
            "user": user.to_dict(),
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "Bearer",
        },
        message="login successful",
        http_status=200,
    )



# ============================================================
#                       REFRESH TOKEN
# ============================================================

@auth_bp.route("/refresh", methods=["POST"])
@jwt_required(refresh=True)
def refresh():
    """
    Refresh JWT access token using a valid refresh token.

    ---
    tags:
      - Auth
    summary: Refresh access token
    security:
      - BearerAuth: []

    responses:
      200:
        description: Token refreshed successfully
      401:
        description: Missing or invalid refresh token
    """

    user_id = get_jwt_identity()
    new_access = create_access_token(identity=str(user_id))

    return api_ok(
        data={"access_token": new_access, "token_type": "Bearer"},
        message="token refreshed",
        http_status=200,
    )



# ============================================================
#                       LOGOUT
# ============================================================

@auth_bp.route("/logout", methods=["POST"])
@jwt_required()
def logout():
    """
    Logout user by blacklisting the current JWT token.

    ---
    tags:
      - Auth
    summary: Logout user
    description: >
      Invalidates the current JWT token by storing its JTI in the blocklist.

    security:
      - BearerAuth: []

    responses:
      200:
        description: Logged out successfully
      401:
        description: Invalid token payload
    """

    jwt_payload = get_jwt()
    jti = jwt_payload.get("jti")
    token_type = jwt_payload.get("type", "access")
    user_id = int(get_jwt_identity())

    if not jti:
        return api_error("invalid token payload", 401)

    db.session.add(
        TokenBlocklist(
            jti=jti,
            token_type=token_type,
            user_id=user_id,
        )
    )
    db.session.commit()

    return api_ok(
        data=None,
        message="logged out",
        http_status=200,
    )
